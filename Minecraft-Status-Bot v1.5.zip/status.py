import discord
import os
import time
from dotenv import load_dotenv
from discord.ext import commands, tasks
from mcstatus import JavaServer
from datetime import datetime, timedelta
import pytz
import asyncio

# 載入 .env 設定
load_dotenv()
TOKEN = os.getenv("DISCORD_TOKEN")
CHANNEL_ID = "1338173560279007315"
SERVERS = [
    {"name": "Java版", "host": "ouo.freeserver.tw", "port": 24488, "is_bungeecord": False},
    {"name": "Bedrock版", "host": "ouo.freeserver.tw", "port": 24488, "is_bungeecord": False}
]
MODE = "geyser"  # 或 'normal'

# Bot 初始化
intents = discord.Intents.default()
client = commands.Bot(command_prefix="/", intents=intents)
status_message = None

# 延遲警示顯示函數
def latency_alert(latency):
    """ 根據延遲顯示警示 """
    if latency < 50:
        return "🟢 延遲良好"
    elif latency > 450:
        return "⚠️ 警告！延遲過高"
    elif latency > 250:
        return "🔴 高延遲"
    elif latency > 120:
        return "🟡 延遲稍高"

# 獲取伺服器狀態的函數
async def fetch_full_status():
    embed = discord.Embed(title="🌐 伺服器狀態", description="最新狀態更新", color=discord.Color.green())
    for s in SERVERS:
        try:
            print(f"正在檢查伺服器 {s['name']}...")
            # 嘗試與伺服器建立連接
            server = JavaServer.lookup(f"{s['host']}:{s['port']}")
            status = server.status()  # 不需要 await，這是同步方法
            print(f"伺服器 {s['name']} 狀態：玩家 {status.players.online}/{status.players.max}，延遲 {status.latency}ms")

            latency_warning = latency_alert(status.latency)
            
            # 如果玩家數為 0，仍然顯示為“線上”
            server_status = "🟢 線上" if status.players.online > 0 else "🟡 線上（無玩家）"
            
            embed.add_field(name=f"**{s['name']}**", value=f"狀態：{server_status}\n延遲：{round(status.latency)}ms ({latency_warning})\n玩家：{status.players.online}/{status.players.max}", inline=False)
        except asyncio.TimeoutError:
            print(f"伺服器 {s['name']} 連接超時")
            embed.add_field(name=f"**{s['name']}**", value="伺服器連接超時 ❌", inline=False)  # 超時處理
        except Exception as e:
            print(f"伺服器 {s['name']} 發生錯誤: {e}")  # 打印錯誤信息
            embed.add_field(name=f"**{s['name']}**", value="伺服器無法連接 ❌", inline=False)  # 通用錯誤處理

    # 計算更新倒數時間並設定格式
    tz = pytz.timezone("Asia/Taipei")  # 設置為臺灣時區
    next_update_time = datetime.utcnow().replace(tzinfo=pytz.utc) + timedelta(seconds=30)
    next_update_time = next_update_time.astimezone(tz)  # 轉換為臺灣時區
    next_update_formatted = next_update_time.strftime("%Y-%m-%d %H:%M:%S %Z")  # 使用臺灣時區格式

    embed.set_footer(text=f"🔄 更新倒數：{next_update_formatted}")  # 顯示格式化後的時間
    return embed

# 查看狀態指令
@client.tree.command(name="查看狀態", description="查看 Minecraft 伺服器的即時狀態")
async def status(interaction: discord.Interaction):
    await interaction.response.send_message(embed=await fetch_full_status())

# 監控更新
@tasks.loop(seconds=30)
async def update_full_status():
    global status_message
    embed = await fetch_full_status()
    channel = client.get_channel(int(CHANNEL_ID))
    if channel:
        if not status_message:
            status_message = await channel.send(embed=embed)
        else:
            await status_message.edit(embed=embed)

@client.event
async def on_ready():
    print(f"✅ 已啟動為 {client.user}")
    await client.tree.sync()
    update_full_status.start()

client.run(TOKEN)